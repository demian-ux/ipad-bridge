import Foundation
import Network
import CoreMedia
import AVFoundation

// Protocolo por TCP (la PC se conecta al iPad, por USB vía usbmux o por IP):
//   cada mensaje = u32 big-endian (largo) + u8 tipo + payload
//   tipo 1 PC->iPad video:  u8 keyframe + f64 timestamp + datos H.264 en formato AVCC (como los da WebCodecs)
//   tipo 2 PC->iPad config: u8 códec (1 = avcC/H.264, 2 = hvcC/HEVC) + record con los parameter sets
//   tipo 3 PC->iPad imagen fija: PNG con los píxeles exactos (pantalla quieta); se muestra encima del video
//   tipo 4 PC->iPad still-clear: volver a mostrar el video
//   tipo 16 iPad->PC input: JSON. Dedos: {"ev":"move|down|up|scroll","x":0..1,"y":0..1,"btn":0|2,"dy":..,"dx":..}
//     Pencil ("pen":1): {"ev":"hover|down|up","x","y","p":presión 0..1,"tx","ty":inclinación en grados},
//     {"ev":"moves","pts":[[x,y,p,tx,ty],...]} (toques coalescidos), {"ev":"leave"}, {"ev":"eraser","on":bool}
//     Barra de teclas (sin "pen"): {"ev":"key","keys":"ctrl+z"} pulsación, {"ev":"mod","key":"shift|ctrl|alt|space","down":bool},
//     {"ev":"text","text":"hola"} texto del teclado; {"ev":"pencfg","gamma","min","smooth"} curva de presión (al conectar y al cambiar)
//   tipo 17 iPad->PC need-key: pedir keyframe
//   tipo 18 iPad->PC JSON de control: {"type":"ping","t":reloj iPad ms,"q","d","rtt"} cada 2 s, {"type":"stats",...} cada 5 s
//   tipo 19 PC->iPad JSON de control: {"type":"pong","t","mt":reloj PC ms,"inp50","inp95",...},
//     {"type":"app","exe","title"} ventana activa de Windows (perfil de la barra), {"type":"shortcuts",gestures,profiles}
//     el contenido de static/shortcuts.json (lo manda usb_bridge.py al conectar; sin él la app usa el perfil embebido)
//   Reloj sincronizado estilo NTP (offset de la muestra de menor RTT de las últimas 15); el input lleva "t" en el reloj
//   de la PC para medir la latencia de input, y cada frame trae ts (f64, reloj de la PC en ms al salir del encoder).

final class Bridge: ObservableObject {
    static let port: UInt16 = 7777

    @Published var status = "Esperando a la PC…"
    @Published var hud = ""
    @Published var addresses = ""
    @Published var penHud = ""      // gesto activo, presión en vivo ("pen 0.42→0.50") o "GOMA" (doble toque del Pencil)

    // Barra de teclas por aplicación: perfiles de shortcuts.json (o el embebido), ventana activa que manda la PC,
    // perfil elegido (automático por ejecutable, o a mano tocando la etiqueta hasta el próximo cambio de app).
    @Published var shortcuts = Shortcuts.fallback
    @Published var appExe = ""
    @Published var appTitle = ""
    @Published var profileIndex = 0
    @Published var manualProfile = false
    @Published var keyboardOn = false    // el campo oculto del teclado es primer respondedor
    @Published var panelOpen = false     // panel ⚙ visible (solo entonces se publica la presión en vivo)
    @Published var penRaw = 0.0          // presión cruda del Pencil para el panel (acotada a ~15 Hz)
    let settings = Settings()
    /// Gestos del perfil activo ya mezclados; lo lee la vista del video en cada toque.
    private(set) var gestureConfig = Shortcuts.fallback.gestureConfig(profileIndex: 0, palmRadius: nil)
    // Estado compartido entre la barra (SwiftUI) y la vista del video (UIKit); solo se toca en el hilo principal.
    var barMouseBtn: Int?                // botón del mouse mantenido desde la barra: el Pencil actúa como ese botón
    var barMouseUsed = false             // el Pencil dibujó con él (al soltar no se manda un clic suelto)
    var penDown = false
    var profile: ShortcutProfile { shortcuts.profiles[min(profileIndex, shortcuts.profiles.count - 1)] }

    private var listener: NWListener?
    private var conn: NWConnection?
    private let queue = DispatchQueue(label: "bridge.net")
    private var format: CMVideoFormatDescription?
    private var nalLength = 4
    private var waitingKey = true
    private var frames = 0
    private var bytes = 0
    private var statsTimer: Timer?
    // Medición: reloj sincronizado con la PC y latencia de llegada de los frames (encoder -> app, antes de decodificar).
    private var clockSamples: [(rtt: Double, offset: Double)] = []
    private var clockOffset: Double?           // reloj PC - reloj iPad, en ms
    private var lastRtt: Double?
    private var inp50: Double?, inp95: Double?
    private var arrival: [Double] = []         // ms entre ts del frame y su llegada a la app
    private var tick = 0

    private var localMs: Double { ProcessInfo.processInfo.systemUptime * 1000 }
    /// Reloj de la PC estimado (ms), o nil si todavía no hubo pong.
    var serverNow: Double? { clockOffset.map { localMs + $0 } }

    /// La vista de video se registra acá para recibir los sample buffers y las imágenes fijas.
    var onSample: ((CMSampleBuffer) -> Void)?
    var onFlush: (() -> Void)?
    var onStill: ((Data?) -> Void)?   // PNG, o nil para volver al video
    var onKeyboardClosed: (() -> Void)?   // el campo del teclado dejó de ser primer respondedor
    private var penCfgWork: DispatchWorkItem?

    init() {
        settings.onPenChange = { [weak self] in self?.schedulePenCfg() }
        settings.onGestureChange = { [weak self] in self?.refreshGestures() }
    }

    /// pencfg al servidor, agrupando los movimientos del deslizador (80 ms, como la página).
    private func schedulePenCfg() {
        penCfgWork?.cancel()
        let w = DispatchWorkItem { [weak self] in
            guard let self = self else { return }
            self.sendInput(self.settings.penConfigMessage)
        }
        penCfgWork = w
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.08, execute: w)
    }

    // MARK: - Perfil de la barra

    func refreshGestures() {
        gestureConfig = shortcuts.gestureConfig(profileIndex: profileIndex, palmRadius: settings.palmRadius >= 0 ? settings.palmRadius : nil)
    }

    /// Elige el perfil por la app activa (salvo que esté fijado a mano) y recalcula los gestos. Hilo principal.
    func pickProfile() {
        if !manualProfile { profileIndex = shortcuts.profileIndex(forExe: appExe) }
        if profileIndex >= shortcuts.profiles.count { profileIndex = 0 }
        refreshGestures()
    }

    /// Tocar la etiqueta del perfil: el siguiente, fijado a mano hasta el próximo cambio de aplicación.
    func nextProfile() {
        manualProfile = true
        profileIndex = (profileIndex + 1) % shortcuts.profiles.count
        refreshGestures()
    }

    func autoProfile() {
        manualProfile = false
        pickProfile()
    }

    private func handleApp(_ m: [String: Any]) {
        DispatchQueue.main.async {
            self.appExe = (m["exe"] as? String) ?? ""
            self.appTitle = (m["title"] as? String) ?? ""
            self.manualProfile = false
            self.pickProfile()
        }
    }

    private func handleShortcuts(_ m: [String: Any]) {
        guard let sc = Shortcuts(json: m) else { return }
        DispatchQueue.main.async {
            self.shortcuts = sc
            self.pickProfile()
        }
    }

    func start() {
        guard listener == nil else { return }
        addresses = localIPs().joined(separator: "  ")
        openListener()
        statsTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in
            guard let s = self else { return }
            let mbps = Double(s.bytes * 8) / 1e6
            let a = s.arrival.sorted()
            let p50 = a.isEmpty ? -1 : a[a.count / 2], p95 = a.isEmpty ? -1 : a[min(a.count - 1, a.count * 95 / 100)]
            s.hud = s.conn == nil ? "" : String(format: "%d fps · %.1f Mbps · llegada %.0f/%.0f ms · in %.0f/%.0f · rtt %.0f",
                                                s.frames, mbps, p50, p95, s.inp50 ?? -1, s.inp95 ?? -1, s.lastRtt ?? -1)
            s.tick += 1
            if s.tick % 2 == 0 {   // ping cada 2 s: reloj + cola (la capa no la expone: 0) + descartes (0) + último RTT
                var m: [String: Any] = ["type": "ping", "t": s.localMs, "q": 0, "d": 0]
                if let r = s.lastRtt { m["rtt"] = r }
                s.sendJSON(m)
            }
            if s.tick % 5 == 0 {   // stats cada 5 s al log de la PC y a pc.html
                s.sendJSON(["type": "stats", "fps": s.frames, "mbps": (mbps * 10).rounded() / 10, "e2e50": p50.rounded(), "e2e95": p95.rounded(),
                            "rtt": (s.lastRtt ?? -1).rounded(), "q": 0, "drops": 0, "transport": "app", "note": "llegada, no presentación"])
                s.arrival.removeAll(keepingCapacity: true)
            }
            s.frames = 0; s.bytes = 0
        }
    }

    /// Abre el puerto; si está ocupado (otra instancia de la app todavía viva), reintenta cada 2 s hasta lograrlo.
    private func openListener() {
        do {
            let params = NWParameters.tcp
            params.allowLocalEndpointReuse = true
            if let tcp = params.defaultProtocolStack.transportProtocol as? NWProtocolTCP.Options { tcp.noDelay = true }
            let l = try NWListener(using: params, on: NWEndpoint.Port(rawValue: Bridge.port)!)
            l.newConnectionHandler = { [weak self] c in self?.accept(c) }
            l.stateUpdateHandler = { [weak self] st in
                guard let self = self else { return }
                switch st {
                case .ready:
                    DispatchQueue.main.async { if self.conn == nil { self.status = "Esperando a la PC…" } }
                case .failed(let e):
                    DispatchQueue.main.async { self.status = "Puerto \(Bridge.port) ocupado (\(e)). Cerrá la otra copia de la app; reintento…" }
                    l.cancel()
                    if self.listener === l { self.listener = nil }
                    self.queue.asyncAfter(deadline: .now() + 2) { [weak self] in
                        guard let self = self, self.listener == nil else { return }
                        self.openListener()
                    }
                default: break
                }
            }
            l.start(queue: queue)
            listener = l
        } catch {
            DispatchQueue.main.async { self.status = "No pude escuchar en \(Bridge.port): \(error)" }
            queue.asyncAfter(deadline: .now() + 2) { [weak self] in
                guard let self = self, self.listener == nil else { return }
                self.openListener()
            }
        }
    }

    func stop() {
        conn?.cancel(); conn = nil
        listener?.cancel(); listener = nil
        statsTimer?.invalidate(); statsTimer = nil
    }

    private func accept(_ c: NWConnection) {
        conn?.cancel()
        conn = c
        format = nil
        waitingKey = true
        c.stateUpdateHandler = { [weak self] st in
            guard let self = self else { return }
            switch st {
            case .ready:
                DispatchQueue.main.async { self.status = "PC conectada, esperando video…" }
                self.send(type: 17, payload: Data())
                self.sendInput(self.settings.penConfigMessage)   // curva de presión guardada: el servidor la aplica ya
                self.readMessage()
            case .failed(let e):
                DispatchQueue.main.async { self.status = "Conexión falló: \(e)" }
                self.disconnected(c)
            case .cancelled:
                self.disconnected(c)
            default: break
            }
        }
        c.start(queue: queue)
    }

    private func disconnected(_ c: NWConnection) {
        if conn === c {
            conn = nil
            onFlush?()
            DispatchQueue.main.async { self.status = "Esperando a la PC…"; self.hud = "" }
        }
    }

    // MARK: - Recepción

    private func readMessage() {
        guard let c = conn else { return }
        c.receive(minimumIncompleteLength: 4, maximumLength: 4) { [weak self] data, _, _, err in
            guard let self = self, let d = data, d.count == 4, err == nil else { self?.conn?.cancel(); return }
            let len = Int(d[0]) << 24 | Int(d[1]) << 16 | Int(d[2]) << 8 | Int(d[3])
            guard len > 0 && len < 32_000_000 else { self.conn?.cancel(); return }
            c.receive(minimumIncompleteLength: len, maximumLength: len) { [weak self] body, _, _, err2 in
                guard let self = self, let b = body, b.count == len, err2 == nil else { self?.conn?.cancel(); return }
                self.handle(type: b[b.startIndex], payload: b.dropFirst())
                self.readMessage()
            }
        }
    }

    private func handle(type: UInt8, payload: Data) {
        switch type {
        case 2:
            let p = Data(payload)
            guard p.count > 1 else { return }
            let record = p.dropFirst()
            format = p[p.startIndex] == 2 ? makeFormatHEVC(hvcC: Data(record)) : makeFormat(avcC: Data(record))
            waitingKey = true
            onFlush?()
            send(type: 17, payload: Data())
            DispatchQueue.main.async { self.status = self.format == nil ? "Config de video inválida" : "" }
        case 3:
            onStill?(Data(payload))
        case 4:
            onStill?(nil)
        case 19:
            if let m = try? JSONSerialization.jsonObject(with: Data(payload)) as? [String: Any] {
                switch m["type"] as? String {
                case "pong": handlePong(m)
                case "app": handleApp(m)
                case "shortcuts": handleShortcuts(m)
                default: break      // tipos nuevos de un puente más nuevo: ignorar
                }
            }
        case 1:
            guard let fmt = format, payload.count > 9 else { return }
            let p = Data(payload)
            let key = p[p.startIndex] == 1
            if waitingKey { if !key { return }; waitingKey = false }
            if let now = serverNow {
                // ts f64 big-endian en los bytes 1..8: reloj de la PC (ms) al salir del encoder
                let bits = p[p.startIndex + 1 ..< p.startIndex + 9].reduce(UInt64(0)) { ($0 << 8) | UInt64($1) }
                let ts = Double(bitPattern: bits)
                if ts > 0 { arrival.append(now - ts); if arrival.count > 600 { arrival.removeFirst(arrival.count - 600) } }
            }
            let nal = p.dropFirst(9)
            if let sample = makeSample(data: Data(nal), format: fmt) {
                frames += 1; bytes += nal.count
                onSample?(sample)
            }
        default: break
        }
    }

    /// pong de la PC: RTT y offset de reloj (muestra de menor RTT de las últimas 15, RTT inválidos descartados).
    private func handlePong(_ m: [String: Any]) {
        guard let t = m["t"] as? Double, let s = m["mt"] as? Double else { return }
        let now = localMs, rtt = now - t
        guard rtt >= 0, rtt < 2000 else { return }
        clockSamples.append((rtt: rtt, offset: s - (t + rtt / 2)))
        if clockSamples.count > 15 { clockSamples.removeFirst() }
        if let best = clockSamples.min(by: { $0.rtt < $1.rtt }) { clockOffset = best.offset }
        lastRtt = rtt
        inp50 = m["inp50"] as? Double
        inp95 = m["inp95"] as? Double
    }

    // MARK: - Envío

    func send(type: UInt8, payload: Data) {
        guard let c = conn else { return }
        var msg = Data(capacity: 5 + payload.count)
        let len = UInt32(1 + payload.count)
        msg.append(contentsOf: [UInt8(len >> 24), UInt8((len >> 16) & 0xff), UInt8((len >> 8) & 0xff), UInt8(len & 0xff)])
        msg.append(type)
        msg.append(payload)
        c.send(content: msg, completion: .contentProcessed { _ in })
    }

    func sendInput(_ dict: [String: Any]) {
        var d = dict
        if let now = serverNow { d["t"] = now }   // reloj de la PC estimado: la PC mide la latencia hasta inyectar
        guard let json = try? JSONSerialization.data(withJSONObject: d) else { return }
        send(type: 16, payload: json)
    }

    /// Clic de ese botón del mouse donde está el cursor (botón de la barra soltado sin haber dibujado).
    func clickAtCursor(_ btn: Int) {
        sendInput(["ev": "down", "btn": btn])
        sendInput(["ev": "up", "btn": btn])
    }

    /// Mensaje JSON de control (ping, stats, quality) a la PC, tipo 18.
    func sendJSON(_ dict: [String: Any]) {
        guard let json = try? JSONSerialization.data(withJSONObject: dict) else { return }
        send(type: 18, payload: json)
    }

    func requestKeyframe() {
        waitingKey = true
        send(type: 17, payload: Data())
    }

    // MARK: - H.264

    private func makeFormat(avcC: Data) -> CMVideoFormatDescription? {
        let b = [UInt8](avcC)
        guard b.count > 7, b[0] == 1 else { return nil }
        nalLength = Int(b[4] & 0x03) + 1
        var sets: [[UInt8]] = []
        var i = 5
        let nSPS = Int(b[i] & 0x1F); i += 1
        for _ in 0..<nSPS {
            guard i + 2 <= b.count else { return nil }
            let len = Int(b[i]) << 8 | Int(b[i + 1]); i += 2
            guard i + len <= b.count else { return nil }
            sets.append(Array(b[i..<i + len])); i += len
        }
        guard i < b.count else { return nil }
        let nPPS = Int(b[i]); i += 1
        for _ in 0..<nPPS {
            guard i + 2 <= b.count else { return nil }
            let len = Int(b[i]) << 8 | Int(b[i + 1]); i += 2
            guard i + len <= b.count else { return nil }
            sets.append(Array(b[i..<i + len])); i += len
        }
        var keep: [UnsafeMutablePointer<UInt8>] = []
        var ptrs: [UnsafePointer<UInt8>] = []
        var sizes: [Int] = []
        for s in sets {
            let p = UnsafeMutablePointer<UInt8>.allocate(capacity: s.count)
            p.initialize(from: s, count: s.count)
            keep.append(p); ptrs.append(UnsafePointer(p)); sizes.append(s.count)
        }
        defer { keep.forEach { $0.deallocate() } }
        var fmt: CMVideoFormatDescription?
        let st = CMVideoFormatDescriptionCreateFromH264ParameterSets(
            allocator: kCFAllocatorDefault, parameterSetCount: sets.count,
            parameterSetPointers: &ptrs, parameterSetSizes: &sizes,
            nalUnitHeaderLength: Int32(nalLength), formatDescriptionOut: &fmt)
        return st == noErr ? fmt : nil
    }

    /// hvcC (HEVCDecoderConfigurationRecord): saltar la cabecera de 22 bytes y leer los arrays de VPS/SPS/PPS.
    private func makeFormatHEVC(hvcC: Data) -> CMVideoFormatDescription? {
        let b = [UInt8](hvcC)
        guard b.count > 23, b[0] == 1 else { return nil }
        nalLength = Int(b[21] & 0x03) + 1
        var sets: [[UInt8]] = []
        var i = 23
        let numArrays = Int(b[22])
        for _ in 0..<numArrays {
            guard i + 3 <= b.count else { return nil }
            i += 1                                           // array_completeness + NAL type
            let n = Int(b[i]) << 8 | Int(b[i + 1]); i += 2
            for _ in 0..<n {
                guard i + 2 <= b.count else { return nil }
                let len = Int(b[i]) << 8 | Int(b[i + 1]); i += 2
                guard i + len <= b.count else { return nil }
                sets.append(Array(b[i..<i + len])); i += len
            }
        }
        guard sets.count >= 3 else { return nil }
        var keep: [UnsafeMutablePointer<UInt8>] = []
        var ptrs: [UnsafePointer<UInt8>] = []
        var sizes: [Int] = []
        for s in sets {
            let p = UnsafeMutablePointer<UInt8>.allocate(capacity: s.count)
            p.initialize(from: s, count: s.count)
            keep.append(p); ptrs.append(UnsafePointer(p)); sizes.append(s.count)
        }
        defer { keep.forEach { $0.deallocate() } }
        var fmt: CMVideoFormatDescription?
        let st = CMVideoFormatDescriptionCreateFromHEVCParameterSets(
            allocator: kCFAllocatorDefault, parameterSetCount: sets.count,
            parameterSetPointers: &ptrs, parameterSetSizes: &sizes,
            nalUnitHeaderLength: Int32(nalLength), extensions: nil, formatDescriptionOut: &fmt)
        return st == noErr ? fmt : nil
    }

    private func makeSample(data: Data, format: CMVideoFormatDescription) -> CMSampleBuffer? {
        var block: CMBlockBuffer?
        let count = data.count
        guard CMBlockBufferCreateWithMemoryBlock(allocator: kCFAllocatorDefault, memoryBlock: nil, blockLength: count,
                                                 blockAllocator: kCFAllocatorDefault, customBlockSource: nil, offsetToData: 0,
                                                 dataLength: count, flags: 0, blockBufferOut: &block) == noErr, let bb = block else { return nil }
        let copied = data.withUnsafeBytes { raw -> OSStatus in
            CMBlockBufferReplaceDataBytes(with: raw.baseAddress!, blockBuffer: bb, offsetIntoDestination: 0, dataLength: count)
        }
        guard copied == noErr else { return nil }
        var sample: CMSampleBuffer?
        var timing = CMSampleTimingInfo(duration: .invalid, presentationTimeStamp: .invalid, decodeTimeStamp: .invalid)
        var size = count
        guard CMSampleBufferCreateReady(allocator: kCFAllocatorDefault, dataBuffer: bb, formatDescription: format, sampleCount: 1,
                                        sampleTimingEntryCount: 1, sampleTimingArray: &timing, sampleSizeEntryCount: 1,
                                        sampleSizeArray: &size, sampleBufferOut: &sample) == noErr, let s = sample else { return nil }
        // Mostrar apenas decodificado, sin esperar a un reloj de presentación.
        if let arr = CMSampleBufferGetSampleAttachmentsArray(s, createIfNecessary: true), CFArrayGetCount(arr) > 0 {
            let dict = unsafeBitCast(CFArrayGetValueAtIndex(arr, 0), to: CFMutableDictionary.self)
            CFDictionarySetValue(dict,
                                 Unmanaged.passUnretained(kCMSampleAttachmentKey_DisplayImmediately).toOpaque(),
                                 Unmanaged.passUnretained(kCFBooleanTrue).toOpaque())
        }
        return s
    }

    private func localIPs() -> [String] {
        var out: [String] = []
        var ifaddr: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&ifaddr) == 0, let first = ifaddr else { return out }
        defer { freeifaddrs(ifaddr) }
        for ptr in sequence(first: first, next: { $0.pointee.ifa_next }) {
            let ifa = ptr.pointee
            guard ifa.ifa_addr.pointee.sa_family == UInt8(AF_INET) else { continue }
            let name = String(cString: ifa.ifa_name)
            guard name.hasPrefix("en") else { continue }
            var host = [CChar](repeating: 0, count: Int(NI_MAXHOST))
            if getnameinfo(ifa.ifa_addr, socklen_t(ifa.ifa_addr.pointee.sa_len), &host, socklen_t(host.count), nil, 0, NI_NUMERICHOST) == 0 {
                out.append(String(cString: host))
            }
        }
        return out
    }
}
